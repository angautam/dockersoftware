# Maintainers

Piotr Bryk <bryk@google.com> and committers to the https://github.com/kubernetes/dashboard repository.


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/dashboard/MAINTAINERS.md?pixel)]()
